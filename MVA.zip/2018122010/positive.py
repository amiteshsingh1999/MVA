#!/usr/bin/env python
# coding: utf-8

# In[6]:


import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats
from scipy.stats import t
import math
x=[-0.1833341, 0.6564449, 0.8725039, 0.3610921, 0.7926144, 0.1833341, -0.6564449, -0.4141061, -0.8725039, 0.8269985, -0.5878715, -0.2950443, -0.3610921, -0.8269985, -0.0470327]
y=[0.0336114, 0.4309199, 0.7612631, 0.1303875, 0.6282377, 0.0336114, 0.4309199, 0.1714839, 0.7612631, 0.6839264, 0.3455929, 0.0870511, 0.1303875, 0.6839264, 0.0022121]
alpha=0.05
n=15
df=n-2
tau,p_value=stats.kendalltau(x,y)
print("Using p value")
print("tau=",end="")

print(tau)
print("p_value=",end="")
print(p_value)
if p_value<alpha:
    print("Null hypothesis rejected and the correlation coefficient is significant providing sufficient evidence for linear relationship between x and y with confidence level of 95%")
else:
    print("Null hypothesis not rejected and the correlation coefficient is not significant providing sufficient evidence for no linear relationship between x and y with confidence level of 95%")
    
print("Using t_critical")
tvalue=(tau*(df**0.5))/((1-tau**2)**0.5)
print("t statistic value=",end="")
print(tvalue)
p = 0.95
# retrieve value <= probability
value = t.ppf(p, df)
print("critical value=",end="")
print(value)
if abs(tvalue)<value:
    print("Null hypothesis not rejected and the correlation coefficient is not significant providing sufficient evidence for no linear relationship between x and y with confidence level of 95%")
else:
    print("Null hypothesis rejected and the correlation coefficient is significant providing sufficient evidence for linear relationship between x and y with confidence level of 95%")

l=np.polyfit(x,y,1)

plt.figure(1)
plt.plot(x, l[0] * np.array(x) + l[1], color='darkblue', linewidth=2)
plt.scatter(x,y)
plt.title("Scatter plot of a parabolic function")
plt.xlabel("x")
plt.ylabel("y")
plt.grid()
plt.show()

