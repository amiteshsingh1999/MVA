#!/usr/bin/env python
# coding: utf-8

# In[32]:


import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats
from scipy.stats import t
import math
cigarettes=[5,23,25,48,17,8,4,26,11,19,14,35,29,4,25]
longevity=[80,78,60,53,85,84,73,79,81,75,68,72,58,92,65]
alpha=0.05
n=15
df=n-2
tau,p_value=stats.kendalltau(cigarettes,longevity)
print("Using p value")
print("tau=",end="")

print(tau)
print("p_value=",end="")
print(p_value)
if p_value<alpha:
    print("Null hypothesis rejected and the correlation coefficient is significant providing sufficient evidence for linear relationship between cigarettes and longevity with confidence level of 95%")
else:
    print("Null hypothesis not rejected and the correlation coefficient is not significant providing sufficient evidence for no linear relationship between cigarettes and longevity with confidence level of 95%")
    
print("Using t_critical")
tvalue=(tau*(df**0.5))/((1-tau**2)**0.5)
print("t statistic value=",end="")
print(tvalue)
p = 0.95
# retrieve value <= probability
value = t.ppf(p, df)
print("critical value=",end="")
print(value)
if abs(tvalue)<value:
    print("Null hypothesis not rejected and the correlation coefficient is not significant providing sufficient evidence for no linear relationship between cigarettes and longevity with confidence level of 95%")
else:
    print("Null hypothesis rejected and the correlation coefficient is significant providing sufficient evidence for linear relationship between cigarettes and longevity with confidence level of 95%")
l=np.polyfit(cigarettes,longevity,1)

plt.figure(1)
plt.plot(cigarettes, l[0] * np.array(cigarettes) + l[1], color='darkblue', linewidth=2)
plt.scatter(cigarettes,longevity)
plt.title("Scatter plot")
plt.xlabel("Number of cigarettes")
plt.ylabel("longevity")
plt.grid()
plt.show()

